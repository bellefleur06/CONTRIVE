<?php

echo "<script>alert('This page is under development.')</script>";
